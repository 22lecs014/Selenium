package CC1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Q1 {

	public static void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		driver.get("https://www.saucedemo.com/");
		Actions a=new Actions (driver);
		driver.get("https://www.saucedemo.com/");
		WebElement user=driver.findElement(By.id("user-name"));
		WebElement pass=driver.findElement(By.id("password"));
		WebElement button=driver.findElement(By.id("login-button"));
		user.sendKeys("standard_user");
		pass.sendKeys("secret_sauce");
		button.click();
		Thread.sleep(3000);
		WebElement addtocart=driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]"));
		addtocart.click();
		WebElement cart=driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a"));
		cart.click();
		WebElement chout=driver.findElement(By.xpath("//*[@id=\"checkout\"]"));
		chout.click();
		WebElement fn=driver.findElement(By.xpath("//*[@id=\"first-name\"]"));
		fn.sendKeys("Prasanna");
		WebElement ln=driver.findElement(By.xpath("//*[@id=\"last-name\"]"));
		ln.sendKeys("Kumar");
		WebElement ps=driver.findElement(By.xpath("//*[@id=\"postal-code\"]"));
		ps.sendKeys("638451");
		WebElement con=driver.findElement(By.xpath("//*[@id=\"continue\"]"));
		con.click();
//		WebElement fin=driver.findElement(By.xpath("//*[@id=\"finish\"]"));
//		fin.click();
		System.out.println("Name of the product: " + driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div[1]/div[3]/div[2]/a/div")).getText());
        System.out.println("Price of the product: " + driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div[1]/div[3]/div[2]/div[2]/div")).getText());
	}
}
