package CIA1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Q1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(co);
		driver.get("https://www.amazon.in/New-Apple-iPhone-12-256GB/dp/B08L5W5Z9Q/ref=sr_1_2_sspa?keywords=iphone+13&qid=1683193403&sr=8-2-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1");
		Actions a=new Actions (driver);
		driver.get("https://www.amazon.in/New-Apple-iPhone-12-256GB/dp/B08L5W5Z9Q/ref=sr_1_2_sspa?keywords=iphone+13&qid=1683193403&sr=8-2-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1");
		driver.manage().window().maximize();
		String currentTitle=driver.getTitle();
		System.out.println(currentTitle);
		String expectedTitle=currentTitle;
		if(currentTitle.equals(expectedTitle)) {
			System.out.println("Title Matched");
		}
		else {
			System.out.println("Title not Matched");
		}
		driver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]")).click();
		WebElement phNo=driver.findElement(By.xpath("//*[@id=\"ap_email\"]"));
		phNo.sendKeys("6382200671");
		Thread.sleep(1000);
		WebElement con=driver.findElement(By.xpath("//*[@id=\"continue\"]"));
		con.click();
		WebElement pass=driver.findElement(By.xpath("//*[@id=\"ap_password\"]"));
		pass.sendKeys("Rithika1619");
		Thread.sleep(1000);
		WebElement signIn1=driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]"));
		signIn1.click();
		Thread.sleep(1000);
//		WebElement pass2=driver.findElement(By.xpath("//*[@id=\"ap_password\"]"));
//		pass2.sendKeys("Rithika1619");
//		Thread.sleep(10000);
//		WebElement signIn2=driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]"));
//		signIn2.click();
//		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
        Thread.sleep(5000); 
        Boolean present = driver.findElement(By.xpath("//*[@id=\"attach-close_sideSheet-link\"]")).isDisplayed();
        System.out.println("Is item added to cart:" + present);
        driver.get("https://www.amazon.in/gp/cart/view.html/ref=dp_atch_dss_cart?");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@value=\"Delete\"]")).click();
        Thread.sleep(2000);
        String removeText = driver.findElement(By.xpath("//*[@id=\"sc-active-cart\"]/div/div[1]/div/h1")).getText();
        String extext = "Your Amazon Cart is empty.";
        if(removeText.equals(extext)) {
        	System.out.println("Product is removed");
        }
        driver.get("https://www.amazon.in/New-Apple-iPhone-12-256GB/dp/B08L5W5Z9Q/ref=sr_1_2_sspa?keywords=iphone+13&qid=1683193403&sr=8-2-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1");
        driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
        Thread.sleep(2000);
        driver.get("https://www.amazon.in/gp/cart/view.html/ref=dp_atch_dss_cart?");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"a-autoid-0-announce\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"quantity_2\"]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@name=\"proceedToRetailCheckout\"] ")).click();
        Thread.sleep(1000);
	}

}
